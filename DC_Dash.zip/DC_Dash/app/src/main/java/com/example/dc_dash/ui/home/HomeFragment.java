package com.example.dc_dash.ui.home;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.example.dc_dash.R;
import android.content.res.Resources;
import android.widget.Spinner;

public class HomeFragment extends Fragment {

    ProgressBar p;
    Spinner spinner;
    private HomeViewModel homeViewModel;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        homeViewModel =
                ViewModelProviders.of(this).get(HomeViewModel.class);
        View root = inflater.inflate(R.layout.fragment_home, container, false);
        final TextView textView = root.findViewById(R.id.text_home);
        homeViewModel.getText().observe(this, new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                textView.setText(s);
            }
        });
        TextView tv = textView.getRootView().findViewById(R.id.tv);
        Resources res = getResources();
        int max = res.getInteger(R.integer.max);
        int numPeople = res.getInteger(R.integer.numPeople);
        double percent = (100.0 * numPeople) / max;

        tv.setText(percent + "%");

        tv = textView.getRootView().findViewById(R.id.DCCount);
        tv.setText("DC Count: " + numPeople);

        // Spinner element
        spinner = textView.getRootView().findViewById(R.id.spinner);

        p = textView.getRootView().findViewById(R.id.circularProgressbar);


        return root;
    }

    public void onResume(){
        super.onResume();
        String a = spinner.getSelectedItem().toString();
        if(a.equals("Segundo")){
            p.setProgress(20);
        }
    }


}